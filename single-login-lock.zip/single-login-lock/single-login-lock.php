<?php
/**
 * Plugin Name: Single Login Lock
 * Description: Restrict each user to only one active login (IP/Device).
 * Version: 1.0
 * Author: Your Name
 */

define('SLL_SESSION_EXPIRY', 3600); // 1 hour session

add_action('init', 'sll_check_concurrent_login');
add_action('wp_login', 'sll_save_login_session', 10, 2);
add_action('wp_logout', 'sll_clear_login_session');

function sll_check_concurrent_login() {
    if (!is_user_logged_in() || get_option('sll_enabled') !== '1') return;

    $user = wp_get_current_user();
    $session = get_user_meta($user->ID, '_sll_session_data', true);
    $current_ip = $_SERVER['REMOTE_ADDR'];
    $cookie_token = $_COOKIE['sll_session_token'] ?? '';

    if ($session) {
        $expired = (time() - $session['time']) > SLL_SESSION_EXPIRY;
        $same_ip = $session['ip'] === $current_ip;
        $same_token = $session['token'] === $cookie_token;

        if (!$expired && (!$same_ip || !$same_token)) {
            wp_logout();
            wp_redirect(home_url());
            exit;
        }
    }
}

function sll_save_login_session($user_login, $user) {
    if (get_option('sll_enabled') !== '1') return;

    $token = bin2hex(random_bytes(16));
    $data = [
        'ip'    => $_SERVER['REMOTE_ADDR'],
        'token' => $token,
        'time'  => time(),
    ];
    update_user_meta($user->ID, '_sll_session_data', $data);

    // Set cookie to identify device
    setcookie('sll_session_token', $token, time() + SLL_SESSION_EXPIRY, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
}

function sll_clear_login_session() {
    $user = wp_get_current_user();
    if ($user && $user->ID) {
        delete_user_meta($user->ID, '_sll_session_data');
    }
    setcookie('sll_session_token', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
}

add_action('admin_menu', function () {
    add_options_page('Single Login Lock', 'Single Login Lock', 'manage_options', 'sll-settings', 'sll_settings_page');
});
add_action('admin_init', function () {
    register_setting('sll_settings_group', 'sll_enabled');
});

function sll_settings_page() {
    $enabled = get_option('sll_enabled', '0');
    ?>
    <div class="wrap">
        <h1>Single Login Lock</h1>
        <form method="post" action="options.php">
            <?php settings_fields('sll_settings_group'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Enable Login Lock</th>
                    <td>
                        <select name="sll_enabled">
                            <option value="0" <?php selected($enabled, '0'); ?>>OFF</option>
                            <option value="1" <?php selected($enabled, '1'); ?>>ON</option>
                        </select>
                        <p class="description">Only one device/IP per user at a time.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action('sll_cleanup_sessions_event', function () {
    $users = get_users([
        'meta_key' => '_sll_session_data',
        'fields' => 'ID'
    ]);

    foreach ($users as $user_id) {
        $data = get_user_meta($user_id, '_sll_session_data', true);
        if (!empty($data['time']) && (time() - $data['time']) > SLL_SESSION_EXPIRY) {
            delete_user_meta($user_id, '_sll_session_data');
        }
    }
});

register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('sll_cleanup_sessions_event')) {
        wp_schedule_event(time(), 'hourly', 'sll_cleanup_sessions_event');
    }
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('sll_cleanup_sessions_event');
});
